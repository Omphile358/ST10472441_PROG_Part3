/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.st10472441_part3_prog5121;

import java.util.Scanner;
import java.util.ArrayList;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.Base64;


/**
 *
 * @author Omphile
 */
public class QuickChat {
      static Message[] sentMessages;
    static Message[] disregardedMessages;
    static Message[] storedMessages;
    static String[] messageHashes;
    static String[] messageIDs;

    static int sentCount = 0;
    static int disregardedCount = 0;
    static int storedCount = 0;

    static final String FILE_NAME = "storedMessages.json"; // JSON storage as requested
    static final String DEVELOPER_NUMBER = "0838884567";

    public static void run(Scanner myInput) {
        int numberOfMessages;
        int choice;
        int messageCount = 0;
        int initialStoredCount;
        String recipient;
        String messageText;
        String result;

        Message.myInput = myInput;

        System.out.println("\nWelcome to QuickChat.");

        System.out.print("How many messages do you want to enter? ");
        numberOfMessages = myInput.nextInt();
        myInput.nextLine();

        while (numberOfMessages < 0) {
            System.out.print("Enter zero or a positive number: ");
            numberOfMessages = myInput.nextInt();
            myInput.nextLine();
        }

        sentMessages = new Message[numberOfMessages];
        disregardedMessages = new Message[numberOfMessages];

        storedMessages = loadStoredMessages();
        storedCount = storedMessages.length;
        initialStoredCount = storedCount;

        messageHashes = new String[numberOfMessages + initialStoredCount];
        messageIDs = new String[numberOfMessages + initialStoredCount];

        for (int i = 0; i < initialStoredCount; i++) {
            messageHashes[i] = storedMessages[i].messageHash;
            messageIDs[i] = storedMessages[i].messageID;
        }

        do {
            System.out.println("\nQuickChat Menu");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Choose an option: ");

            choice = myInput.nextInt();
            myInput.nextLine();

            switch (choice) {
                case 1:
                    if (messageCount >= numberOfMessages) {
                        System.out.println("You have entered the requested number of messages.");
                        break;
                    }

                    while (messageCount < numberOfMessages) {
                        Message myMessage = new Message(messageCount);
                        myMessage.sender = DEVELOPER_NUMBER;

                        System.out.println("\nMessage " + (messageCount + 1));
                        System.out.print("Enter recipient number (+27): ");
                        recipient = myInput.nextLine();
                        myMessage.recipient = recipient;

                        while (!myMessage.checkRecipientCell().equals("Cell phone number successfully captured.")) {
                            System.out.println(myMessage.checkRecipientCell());
                            System.out.print("Enter recipient number again: ");
                            recipient = myInput.nextLine();
                            myMessage.recipient = recipient;
                        }

                        System.out.print("Enter your message: ");
                        messageText = myInput.nextLine();
                        myMessage.message = messageText;

                        while (!myMessage.checkMessageLength().equals("Message ready to send.")) {
                            System.out.println(myMessage.checkMessageLength());
                            System.out.print("Enter your message again: ");
                            messageText = myInput.nextLine();
                            myMessage.message = messageText;
                        }

                        myMessage.createMessageHash();
                        result = myMessage.SendMessage();
                        System.out.println(result);

                        if (myMessage.flag.equals("Sent")) {
                            sentMessages[sentCount] = myMessage;
                            sentCount++;
                        } else if (myMessage.flag.equals("Disregard")) {
                            disregardedMessages[disregardedCount] = myMessage;
                            disregardedCount++;
                        } else if (myMessage.flag.equals("Stored")) {
                            addStoredMessage(myMessage);
                            saveAllStoredMessages();
                        }

                        int arrayPosition = initialStoredCount + messageCount;
                        messageHashes[arrayPosition] = myMessage.messageHash;
                        messageIDs[arrayPosition] = myMessage.messageID;

                        System.out.println(myMessage.printMessages());
                        messageCount++;
                    }
                    break;

                case 2:
                    if (sentCount == 0) {
                        System.out.println("No sent messages available.");
                    } else {
                        for (int i = 0; i < sentCount; i++) {
                            System.out.println(sentMessages[i].printMessages());
                            System.out.println();
                        }
                    }
                    break;

                case 3:
                    System.out.println("Exiting QuickChat.");
                    break;

                case 4:
                    storedMessagesMenu(myInput);
                    break;

                default:
                    System.out.println("Invalid option.");
            }

        } while (choice != 3);

        System.out.println("\nTotal messages sent: " + Message.totalMessagesSent);
    }

    public static void addStoredMessage(Message myMessage) {
        Message[] updatedMessages = new Message[storedCount + 1];
        for (int i = 0; i < storedCount; i++) {
            updatedMessages[i] = storedMessages[i];
        }
        updatedMessages[storedCount] = myMessage;
        storedMessages = updatedMessages;
        storedCount++;
    }

    public static void storedMessagesMenu(Scanner myInput) {
        int choice;
        do {
            System.out.println("\nStored Messages Menu");
            System.out.println("1) Display sender and recipient");
            System.out.println("2) Display longest stored message");
            System.out.println("3) Search by message ID");
            System.out.println("4) Search messages by recipient");
            System.out.println("5) Delete message using message hash");
            System.out.println("6) Display message report");
            System.out.println("7) Return to main menu");
            System.out.print("Choose an option: ");

            choice = myInput.nextInt();
            myInput.nextLine();

            switch (choice) {
                case 1:
                    displaySenderAndRecipient();
                    break;
                case 2:
                    displayLongestMessage();
                    break;
                case 3:
                    searchMessageID(myInput);
                    break;
                case 4:
                    searchRecipient(myInput);
                    break;
                case 5:
                    deleteMessage(myInput);
                    break;
                case 6:
                    displayReport();
                    break;
                case 7:
                    System.out.println("Returning to main menu.");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } while (choice != 7);
    }

    public static void displaySenderAndRecipient() {
        System.out.println("\nSender and Recipient Details (Stored Messages)");
        for (int i = 0; i < storedCount; i++) {
            System.out.println("Sender: " + storedMessages[i].sender);
            System.out.println("Recipient: " + storedMessages[i].recipient);
        }
    }

    public static void displayLongestMessage() {
        if (storedCount == 0) {
            System.out.println("There are no stored messages.");
            return;
        }

        Message longestMessage = storedMessages[0];
        for (int i = 1; i < storedCount; i++) {
            if (storedMessages[i].message.length() > longestMessage.message.length()) {
                longestMessage = storedMessages[i];
            }
        }

        System.out.println("Longest stored message:");
        System.out.println(longestMessage.message);
    }

    public static void searchMessageID(Scanner myInput) {
        System.out.print("Enter message ID: ");
        String searchID = myInput.nextLine();
        boolean found = false;

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].messageID.equals(searchID)) {
                System.out.println("Recipient: " + storedMessages[i].recipient);
                System.out.println("Message: " + storedMessages[i].message);
                found = true;
            }
        }

        if (!found) {
            System.out.println("Message ID not found.");
        }
    }

    public static void searchRecipient(Scanner myInput) {
        System.out.print("Enter recipient number: ");
        String searchNumber = myInput.nextLine();
        boolean found = false;

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].recipient.equals(searchNumber)) {
                System.out.println(storedMessages[i].message);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    public static void deleteMessage(Scanner myInput) {
        System.out.print("Enter message hash: ");
        String searchHash = myInput.nextLine();
        boolean found = false;

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].messageHash.equals(searchHash)) {
                System.out.println("\"" + storedMessages[i].message + "\" successfully deleted.");

                for (int j = i; j < storedCount - 1; j++) {
                    storedMessages[j] = storedMessages[j + 1];
                }

                storedCount--;
                Message[] updatedMessages = new Message[storedCount];
                for (int j = 0; j < storedCount; j++) {
                    updatedMessages[j] = storedMessages[j];
                }
                storedMessages = updatedMessages;

                saveAllStoredMessages();
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Message hash not found.");
        }
    }

    public static void displayReport() {
        System.out.println("\nStored Message Report");
        for (int i = 0; i < storedCount; i++) {
            System.out.println("Message Hash: " + storedMessages[i].messageHash);
            System.out.println("Recipient: " + storedMessages[i].recipient);
            System.out.println("Message: " + storedMessages[i].message);
            System.out.println();
        }
    }

    public static Message[] loadStoredMessages() {
        ArrayList<Message> messages = new ArrayList<>();
        try {
            if (Files.exists(Paths.get(FILE_NAME))) {
                java.util.List<String> lines = Files.readAllLines(Paths.get(FILE_NAME), StandardCharsets.UTF_8);
                for (String line : lines) {
                    String[] parts = line.split("\\|", -1);
                    if (parts.length == 5) {
                        Message myMessage = new Message(0);
                        myMessage.sender = decode(parts[0]);
                        myMessage.recipient = decode(parts[1]);
                        myMessage.message = decode(parts[2]);
                        myMessage.messageID = decode(parts[3]);
                        myMessage.messageHash = decode(parts[4]);
                        myMessage.flag = "Stored";
                        messages.add(myMessage);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Unable to load stored messages.");
        }
        return messages.toArray(new Message[0]);
    }

    public static void saveAllStoredMessages() {
        try {
            ArrayList<String> lines = new ArrayList<>();
            for (int i = 0; i < storedCount; i++) {
                Message myMessage = storedMessages[i];
                String line = encode(myMessage.sender) + "|"
                        + encode(myMessage.recipient) + "|"
                        + encode(myMessage.message) + "|"
                        + encode(myMessage.messageID) + "|"
                        + encode(myMessage.messageHash);
                lines.add(line);
            }
            Files.write(Paths.get(FILE_NAME), lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("Unable to update stored messages.");
        }
    }

    public static String encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    public static String decode(String value) {
        return new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
    }
}