/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.st10472441_part3_prog5121;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Omphile
 */
public class Message {
    // Declarations
    public String messageID;
    public String sender;
    public String recipient;
    public String message;
    public String messageHash;
    public String flag;
    public int messageNumber;

    static int totalMessagesSent = 0;
    public static Scanner myInput;

     public Message(int messageNumber) {
        Random random = new Random();
        this.messageNumber = messageNumber;
        long randomID = 1000000000L + (long) (random.nextDouble() * 9000000000L);
        messageID = String.valueOf(randomID);
    }

    // Overloaded constructor for specific test data IDs (e.g., Test Data 4)
    public Message(int messageNumber, String messageID) {
        this.messageNumber = messageNumber;
        this.messageID = messageID;
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.matches("[0-9]{1,10}");
    }

    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+27[0-9]{9}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell number is incorrectly formatted.";
        }
    }

    public String checkMessageLength() {
        if (message != null && !message.trim().isEmpty() && message.length() <= 250) {
            return "Message ready to send.";
        } else if (message == null || message.trim().isEmpty()) {
            return "Message cannot be empty.";
        } else {
            return "Message exceeds 250 characters by "
                    + (message.length() - 250)
                    + ", please reduce size.";
        }
    }

    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = message.trim().split("\\s+");

        String firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");

        messageHash = (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
        return messageHash;
    }

    public String SendMessage() {
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        System.out.print("Choose an option: ");

        String choice = myInput.nextLine();

        if (choice.equals("1")) {
            flag = "Sent";
            totalMessagesSent++;
            return "Message successfully sent.";
        } else if (choice.equals("2")) {
            flag = "Disregard";
            return "Message disregarded.";
        } else if (choice.equals("3")) {
            flag = "Stored";
            return "Message successfully stored.";
        } else {
            flag = "Invalid";
            return "Invalid choice.";
        }
    }

    public String printMessages() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nSender: " + sender
                + "\nRecipient: " + recipient
                + "\nMessage: " + message
                + "\nFlag: " + flag;
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }
}