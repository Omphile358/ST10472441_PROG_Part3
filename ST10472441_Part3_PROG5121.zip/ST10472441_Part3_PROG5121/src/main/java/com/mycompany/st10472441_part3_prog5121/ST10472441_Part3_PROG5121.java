/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.st10472441_part3_prog5121;

import java.util.Scanner;

/**
 *
 * @author Omphile
 */
public class ST10472441_Part3_PROG5121 {

    public static void main(String[] args) {
       // Declarations
        Scanner myInput = new Scanner(System.in);
        String username;
        String password;
        String cellPhone;
        String loginStatus;

        Login myRegistration = new Login();

        // Registration

        do {
            System.out.print("Enter username: ");
            username = myInput.nextLine();
            myRegistration.username = username;

            if (!myRegistration.checkUserName()) {
                System.out.println("Username must contain an underscore "
                        + "and be no more than five characters.");
            }

        } while (!myRegistration.checkUserName());

        do {
            System.out.print("Enter password: ");
            password = myInput.nextLine();
            myRegistration.password = password;

            if (!myRegistration.checkPasswordComplexity()) {
                System.out.println("Password must have at least eight "
                        + "characters, a capital letter, a number "
                        + "and a special character.");
            }

        } while (!myRegistration.checkPasswordComplexity());

        do {
            System.out.print("Enter South African cell number (+27): ");
            cellPhone = myInput.nextLine();
            myRegistration.cellPhone = cellPhone;

            if (!myRegistration.checkCellPhoneNumber()) {
                System.out.println("Cell number is incorrectly formatted.");
            }

        } while (!myRegistration.checkCellPhoneNumber());

        System.out.println(myRegistration.registerUser());

        // Login

        System.out.println("\nLogin");

        System.out.print("Enter username to login: ");
        username = myInput.nextLine();

        System.out.print("Enter password to login: ");
        password = myInput.nextLine();

        loginStatus = myRegistration.returnLoginStatus(
                username, password);

        System.out.println(loginStatus);

        if (loginStatus.equals(
                "Welcome user, it is great to see you again.")) {

            QuickChat.run(myInput);
        }

        myInput.close();
    }
}